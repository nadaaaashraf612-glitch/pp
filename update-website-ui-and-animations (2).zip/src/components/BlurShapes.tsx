"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

type Shape = {
  kind: "circle" | "pill" | "ring" | "square";
  /** position in % (logical: x measured from the inline-start edge) */
  x: number;
  y: number;
  size: number;
  rotate?: number;
  opacity: number;
  blur: number;
  speed: number; // parallax px
  dur: number; // float seconds
};

const LAYOUTS: Shape[][] = [
  [
    { kind: "circle", x: 82, y: 8, size: 340, opacity: 1, blur: 90, speed: 70, dur: 14 },
    { kind: "pill", x: 6, y: 70, size: 300, rotate: -24, opacity: 0.8, blur: 70, speed: -50, dur: 17 },
    { kind: "ring", x: 48, y: 88, size: 180, opacity: 0.9, blur: 14, speed: 30, dur: 12 },
  ],
  [
    { kind: "pill", x: 70, y: 62, size: 380, rotate: 32, opacity: 0.9, blur: 80, speed: 60, dur: 16 },
    { kind: "circle", x: -4, y: 12, size: 300, opacity: 0.9, blur: 85, speed: -60, dur: 13 },
    { kind: "square", x: 56, y: 6, size: 120, rotate: 18, opacity: 0.8, blur: 18, speed: 40, dur: 11 },
  ],
  [
    { kind: "circle", x: 40, y: -8, size: 420, opacity: 0.8, blur: 100, speed: 50, dur: 18 },
    { kind: "ring", x: 88, y: 66, size: 240, opacity: 0.9, blur: 12, speed: -40, dur: 14 },
    { kind: "pill", x: 4, y: 82, size: 260, rotate: -12, opacity: 0.8, blur: 70, speed: 40, dur: 15 },
  ],
  [
    { kind: "square", x: 8, y: 14, size: 200, rotate: -16, opacity: 0.9, blur: 40, speed: -50, dur: 15 },
    { kind: "circle", x: 78, y: 70, size: 360, opacity: 1, blur: 95, speed: 70, dur: 13 },
    { kind: "pill", x: 60, y: 4, size: 280, rotate: 40, opacity: 0.7, blur: 65, speed: 35, dur: 17 },
  ],
];

export function BlurShapes({ tone = "light", seed = 0 }: { tone?: "light" | "dark"; seed?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const layout = LAYOUTS[seed % LAYOUTS.length];
  const dark = tone === "dark";

  return (
    <div ref={ref} aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      {layout.map((s, i) => (
        <ParallaxShape key={i} s={s} dark={dark} progress={scrollYProgress} />
      ))}
    </div>
  );
}

function ParallaxShape({
  s,
  dark,
  progress,
}: {
  s: Shape;
  dark: boolean;
  progress: ReturnType<typeof useScroll>["scrollYProgress"];
}) {
  const y = useTransform(progress, [0, 1], [s.speed, -s.speed]);
  const fill = dark ? "rgba(255,255,255,0.09)" : "rgba(0,0,0,0.075)";
  const line = dark ? "rgba(255,255,255,0.22)" : "rgba(0,0,0,0.16)";

  const base: React.CSSProperties = {
    width: s.size,
    height: s.kind === "pill" ? s.size * 0.42 : s.size,
    filter: `blur(${s.blur}px)`,
    opacity: s.opacity,
    insetInlineStart: `${s.x}%`,
    top: `${s.y}%`,
  };
  const look: React.CSSProperties =
    s.kind === "ring"
      ? { border: `2px solid ${line}`, borderRadius: "9999px" }
      : {
          background: dark
            ? `linear-gradient(145deg, rgba(255,255,255,0.16), ${fill})`
            : `linear-gradient(145deg, rgba(0,0,0,0.1), ${fill})`,
          borderRadius: s.kind === "circle" ? "9999px" : s.kind === "pill" ? "9999px" : "28%",
        };

  return (
    <motion.span className="absolute block" style={{ ...base, y }}>
      <motion.span
        className="block h-full w-full"
        style={{ ...look, rotate: s.rotate ?? 0 }}
        animate={{ x: [0, 22, -10, 0], y: [0, -18, 12, 0], scale: [1, 1.06, 0.97, 1] }}
        transition={{ duration: s.dur, repeat: Infinity, ease: "easeInOut" }}
      />
    </motion.span>
  );
}
