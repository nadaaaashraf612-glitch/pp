"use client";

import { memo } from "react";
import * as THREE from "three";
import { GlassCanvas } from "./GlassCanvas";
import { glassMaterial, type StageOpts } from "./kit";

/**
 * "Held, then lifted" — the cradle of the PUIUX mark (the U with round shoulders) carries a
 * single ink-glass sphere (the idea) that rises out of it and settles back, sending a faint
 * ripple across the floor. Not the logo itself: the story the logo tells.
 */
const opts: StageOpts = {
  tone: "light",
  frame: { w: 3.8, h: 3.6 },
  tilt: 0.12,
  introSeconds: 2.2,
  setup({ scene }) {
    const smoked = glassMaterial({ smoke: 0x2e2e2e, distance: 1.1, thickness: 0.55, tint: 0x6e6e6e, envMapIntensity: 1.9 });
    const ink = glassMaterial({ smoke: 0x181818, distance: 0.6, thickness: 0.9, tint: 0x4c4c4c, envMapIntensity: 2.2 });

    const R = 1.05;
    const tube = 0.2;
    const group = new THREE.Group();

    const cradleGeo = new THREE.TorusGeometry(R, tube, 56, 160, Math.PI);
    const cradle = new THREE.Mesh(cradleGeo, smoked);
    cradle.rotation.z = Math.PI; // keep the lower half → a "U"
    group.add(cradle);

    // round shoulders, echoing the two lobes of the mark
    const knobGeo = new THREE.SphereGeometry(tube * 1.5, 48, 32);
    const kl = new THREE.Mesh(knobGeo, smoked);
    kl.position.set(-R, 0, 0);
    const kr = new THREE.Mesh(knobGeo, smoked);
    kr.position.set(R, 0, 0);
    group.add(kl, kr);

    const ballGeo = new THREE.SphereGeometry(0.5, 64, 48);
    const ball = new THREE.Mesh(ballGeo, ink);
    group.add(ball);

    // floor ripples (hairlines)
    const rippleMat = new THREE.MeshBasicMaterial({ color: 0x111111, transparent: true, opacity: 0.25 });
    const ripples = [0, 1].map(() => {
      const m = new THREE.Mesh(new THREE.TorusGeometry(1, 0.006, 6, 120), rippleMat.clone());
      m.rotation.x = Math.PI / 2;
      m.position.y = -1.45;
      group.add(m);
      return m;
    });

    group.position.y = 0.12;
    scene.add(group);

    return {
      update(t, cur, intro) {
        group.rotation.y = Math.sin(t * 0.45) * 0.55 + (1 - intro) * 2.4 + cur.x * 0.45;
        group.rotation.x = cur.y * 0.18;
        group.scale.setScalar(0.6 + 0.4 * intro);

        // 0 = resting in the cradle, 1 = lifted
        const lift = (Math.sin(t * 0.9 - Math.PI / 2) + 1) / 2;
        const eased = lift * lift * (3 - 2 * lift);
        ball.position.y = -0.38 + eased * 1.35;
        ball.rotation.y = t * 0.6;

        ripples.forEach((r, i) => {
          const p = (t * 0.28 + i * 0.5) % 1;
          const s = 0.35 + p * 1.5;
          r.scale.set(s, s, s);
          (r.material as THREE.MeshBasicMaterial).opacity = (1 - p) * 0.28;
        });
      },
      dispose() {
        cradleGeo.dispose();
        knobGeo.dispose();
        ballGeo.dispose();
        smoked.dispose();
        ink.dispose();
        rippleMat.dispose();
        ripples.forEach((r) => {
          r.geometry.dispose();
          (r.material as THREE.Material).dispose();
        });
      },
    };
  },
};

function AboutGlassBase({ className }: { className?: string }) {
  return <GlassCanvas className={className} opts={opts} feather={66} />;
}

export const AboutGlass = memo(AboutGlassBase);
