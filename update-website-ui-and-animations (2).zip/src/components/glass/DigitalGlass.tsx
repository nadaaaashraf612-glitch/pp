"use client";

import { memo } from "react";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { GlassCanvas } from "./GlassCanvas";
import { glassMaterial, type StageOpts } from "./kit";

/**
 * "Make it digital" — the dot of the PUIUX mark (the idea) floats above a field of glass
 * pixels. Wherever the idea hovers, the pixels rise in a ripple: analog → digital.
 */
const N = 5;
const GAP = 0.5;

const opts: StageOpts = {
  tone: "light",
  frame: { w: 4.6, h: 3.9 },
  tilt: 0.62,
  introSeconds: 2.2,
  setup({ scene }) {
    const smoked = glassMaterial({ smoke: 0x2e2e2e, distance: 1.0, thickness: 0.4, tint: 0x6e6e6e, envMapIntensity: 1.9 });
    const ink = glassMaterial({ smoke: 0x181818, distance: 0.6, thickness: 0.9, tint: 0x4c4c4c, envMapIntensity: 2.2 });

    const group = new THREE.Group();
    const cubeGeo = new RoundedBoxGeometry(0.38, 1, 0.38, 5, 0.07);
    const cubes: { mesh: THREE.Mesh; d: number }[] = [];
    const c = (N - 1) / 2;
    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        if (i === c && j === c) continue;
        const mesh = new THREE.Mesh(cubeGeo, smoked);
        mesh.position.set((i - c) * GAP, 0, (j - c) * GAP);
        group.add(mesh);
        cubes.push({ mesh, d: Math.hypot(i - c, j - c) });
      }
    }

    const ballGeo = new THREE.SphereGeometry(0.4, 64, 48);
    const ball = new THREE.Mesh(ballGeo, ink);
    group.add(ball);

    group.position.y = -0.55;
    scene.add(group);

    return {
      update(t, cur, intro) {
        group.rotation.y = t * 0.18 + (1 - intro) * 2 + cur.x * 0.4;
        group.rotation.x = cur.y * 0.08;
        group.scale.setScalar(0.65 + 0.35 * intro);

        const bob = Math.sin(t * 1.2) * 0.12;
        ball.position.y = 1.15 + bob;
        ball.rotation.y = t * 0.5;

        for (const { mesh, d } of cubes) {
          const wave = Math.max(0, Math.sin(d * 1.7 - t * 1.9));
          const h = 0.16 + wave * wave * (1.25 - d * 0.16) * intro;
          mesh.scale.y = Math.max(h, 0.08);
          mesh.position.y = mesh.scale.y / 2;
        }
      },
      dispose() {
        cubeGeo.dispose();
        ballGeo.dispose();
        smoked.dispose();
        ink.dispose();
      },
    };
  },
};

function DigitalGlassBase({ className }: { className?: string }) {
  return <GlassCanvas className={className} opts={opts} feather={64} />;
}

export const DigitalGlass = memo(DigitalGlassBase);
