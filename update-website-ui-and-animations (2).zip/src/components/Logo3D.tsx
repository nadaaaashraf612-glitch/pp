"use client";

import { memo } from "react";
import * as THREE from "three";
import { SVGLoader } from "three/addons/loaders/SVGLoader.js";
import { GlassCanvas } from "./glass/GlassCanvas";
import { ICON_DOT, ICON_PATH, glassMaterial, type StageOpts } from "./glass/kit";
import { LogoIllustration } from "./LogoIllustration";

function buildLogoGeometry() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg"><path d="${ICON_PATH}"/></svg>`;
  const data = new SVGLoader().parse(svg);
  const shapes = data.paths[0].toShapes();

  const body = new THREE.ExtrudeGeometry(shapes, {
    depth: 84,
    curveSegments: 40,
    bevelEnabled: true,
    bevelThickness: 26,
    bevelSize: 18,
    bevelSegments: 10,
  });

  // the "dot" becomes a true sphere sitting inside the cradle
  const dot = new THREE.SphereGeometry(ICON_DOT.rx * 1.02, 64, 48);

  body.scale(1, -1, 1);
  body.computeBoundingBox();
  const c = new THREE.Vector3();
  body.boundingBox!.getCenter(c);
  body.translate(-c.x, -c.y, -c.z);
  dot.translate(ICON_DOT.cx - c.x, -ICON_DOT.cy - c.y, 0);
  body.computeVertexNormals();

  const width = body.boundingBox!.max.x - body.boundingBox!.min.x;
  return { body, dot, width };
}

const heroOpts: StageOpts = {
  tone: "dark",
  frame: { w: 4.8, h: 4.0 },
  introSeconds: 2.6,
  setup({ scene }) {
    // ink-smoke glass for the cradle, denser "ink drop" glass for the dot
    const smoked = glassMaterial({ smoke: 0x484848, distance: 1.4, thickness: 130, tint: 0x8a8a8a, envMapIntensity: 2.3 });
    const ink = glassMaterial({ smoke: 0x202020, distance: 0.8, thickness: 140, tint: 0x555555, envMapIntensity: 2.6 });

    const { body, dot, width } = buildLogoGeometry();
    const unit = 2.7 / width;

    const hero = new THREE.Group();
    const logo = new THREE.Group();
    logo.scale.setScalar(unit);
    logo.add(new THREE.Mesh(body, smoked), new THREE.Mesh(dot, ink));
    hero.add(logo);
    scene.add(hero);

    // orbiting miniature glass marks
    const orbit = new THREE.Group();
    orbit.rotation.set(1.15, 0.2, 0.35);
    const minis: THREE.Group[] = [];
    const MINI = 4;
    for (let i = 0; i < MINI; i++) {
      const m = new THREE.Group();
      const inner = new THREE.Group();
      inner.scale.setScalar(unit * 0.1);
      inner.add(new THREE.Mesh(body, smoked), new THREE.Mesh(dot, ink));
      m.add(inner);
      orbit.add(m);
      minis.push(m);
    }
    scene.add(orbit);

    // hairline rings (white, very faint)
    const ringMat = (o: number) => new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: o });
    const ring1 = new THREE.Mesh(new THREE.TorusGeometry(2.0, 0.004, 8, 220), ringMat(0.3));
    ring1.rotation.set(1.15, 0.2, 0.35);
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(2.3, 0.003, 8, 240), ringMat(0.12));
    ring2.rotation.set(0.5, -0.6, 0.1);
    scene.add(ring1, ring2);

    return {
      update(t, cur, intro) {
        const spinIn = (1 - intro) * Math.PI * 3;
        hero.rotation.y = Math.sin(t * 0.55) * 0.75 + spinIn + cur.x * 0.5;
        hero.rotation.x = Math.sin(t * 0.7) * 0.12 + cur.y * 0.28;
        hero.rotation.z = Math.sin(t * 0.5) * 0.04;
        hero.position.y = Math.sin(t * 1.1) * 0.07;
        hero.scale.setScalar(0.55 + intro * 0.45);

        orbit.rotation.y = 0.2 + cur.x * 0.12;
        orbit.rotation.x = 1.15 + cur.y * 0.1;
        minis.forEach((m, i) => {
          const a = t * 0.5 + (i / MINI) * Math.PI * 2;
          m.position.set(Math.cos(a) * 2.0 * intro, Math.sin(a) * 2.0 * intro, 0);
          m.rotation.set(t * 0.8 + i, t * 1.1 + i * 0.6, 0);
        });
        ring1.rotation.z = 0.35 + t * 0.05;
        ring2.rotation.z = 0.1 - t * 0.04;
        ring2.rotation.y = -0.6 + Math.sin(t * 0.3) * 0.15;
      },
      dispose() {
        body.dispose();
        dot.dispose();
        smoked.dispose();
        ink.dispose();
        [ring1, ring2].forEach((r) => {
          r.geometry.dispose();
          (r.material as THREE.Material).dispose();
        });
      },
    };
  },
};

/**
 * Hero illustration: the PUIUX mark as transparent black glass — a smoked cradle holding a
 * dense ink-glass sphere — slowly turning, refracting soft studio light bands.
 * Falls back to the SVG illustration when WebGL isn't available.
 */
function Logo3DBase({ className }: { className?: string }) {
  return (
    <GlassCanvas
      className={className}
      opts={heroOpts}
      feather={64}
      fallback={<LogoIllustration chips={2} className="absolute inset-0" />}
    />
  );
}

export const Logo3D = memo(Logo3DBase);
